# Mathematics Simulator — Landing

The product landing page for [Mathematics Simulator](https://github.com/Max-arango/Mathematics-simulator), an open-source mathematical exploration environment. This repository is an independent presentation layer: it presents the simulator, but it is not the simulator itself, and nothing here is imported from the main application's code.

- Live simulator: https://mathematics-simulator.vercel.app
- Source repository: https://github.com/Max-arango/Mathematics-simulator

## What's on the page

A single route (`/`) that reads as a live mathematical exhibit, top to bottom:

- **Hero** — a live, rotating 3D surface (wireframe rendered on a 2D canvas). The pointer tilts the camera; hovering samples the nearest mesh vertex.
- **One mathematical engine** — the Expression → Lexer → Parser → AST → Engine pipeline that feeds every workspace, presented as a staged instrument diagram, together with the engine capability list and the simulator's stack.
- **Nine workspaces** — Calculator, Fractal Lab, Bloch Sphere, 4D, Topology, Dynamics, Inspector, Notebook and Docs, each with its route.
- **Interactive function lab** — f(x) = a·sin(bx + c) with live sliders, derived quantities and an on-canvas tangent probe.
- **Fractal Lab explorer** — Mandelbrot, Julia (drag to set c), Burning Ship, Tricorn and Newton (z³ − 1) basins, with iteration and palette controls.
- **Geometry** — the dimension ladder sphere → torus → tesseract. Drag to orbit; the tesseract exposes its two rotation planes (XY / ZW) as sliders.
- **Dynamics** — Van der Pol phase portrait with a real vector field and RK4 trajectories; click to drop seeds, drag to move them.
- **Inspector** — expression → AST → symbolic derivative → classified critical points.
- **Notebook** — a reproducible experiment: edit draft parameters, run, and watch the cells recompute in dependency order, like a reactive notebook.
- **Open source** — the MIT license, repository links and a contribution invitation.
- **Built for exploration** — four conceptual feature cards (unified, visual, experimental, open).
- **Final CTA** — links to the live simulator and the repository.

Every demo on the page is a standalone, dependency-free canvas/SVG computation written for this landing. Nothing is imported from the main simulator's math engine; each visualization is a self-contained re-implementation of the phenomenon it presents.

## Tech stack

- Next.js 16 (App Router), React 19, TypeScript
- Tailwind CSS 4 with a custom "mathematical laboratory" theme, shadcn/ui primitives, lucide-react icons
- Self-hosted fonts via `next/font/local` from `src/fonts`: Inter (variable), Instrument Serif (regular + italic), JetBrains Mono (variable)
- All demos render with plain Canvas 2D / SVG — no charting library, no WebGL
- SEO: full metadata (Open Graph, Twitter, canonical URL), a generated Open Graph image and an SVG favicon

## Getting started

```bash
npm install        # or: bun install / pnpm install
npm run dev        # http://localhost:3000
```

Production:

```bash
npm run build
npm start
```

Code quality: `npm run lint` (ESLint). No environment variables are required.

## Project structure

```
src/
  app/
    layout.tsx            Root layout: self-hosted fonts, metadata, theme color
    page.tsx              The landing — single route "/"
    globals.css           Tailwind 4 theme and design tokens
    icon.svg              Favicon
    opengraph-image.tsx   Generated Open Graph image
  components/
    landing/              Section components (navbar, hero, engine, workspaces,
                          interactive, fractal, geometry, dynamics, inspector,
                          notebook, open-source, why, CTA, footer, primitives)
    math/                 Canvas demo components + hooks.ts (reduced-motion,
                          in-view, sizing) + lib.ts (shared math/format helpers)
  data/
    workspaces.ts         workspaceMetadata (9), engineCapabilities, stackChips
    features.ts           featureConcepts (4)
    examples.ts           featuredExamples (6)
  fonts/                  Self-hosted woff2 files
supabase/
  schema.sql              Future data layer (design artifact — not applied)
  seed.sql                Future seed data (design artifact — not applied)
```

## Supabase — future integration

`supabase/schema.sql` and `supabase/seed.sql` define the intended future data layer. They are design artifacts only:

- **schema.sql** — the enums `visibility_type`, `workspace_type` and `experiment_status`; the tables `profiles`, `workspace_metadata`, `projects`, `experiments`, `notebooks`, `examples` and `tags`, plus the join tables `experiment_tags`, `project_tags` and `notebook_tags`; `set_updated_at()` triggers on every table with an `updated_at` column; and indexes, including a partial index on featured examples. The Row Level Security block is intentionally **commented out**: RLS must be enabled and per-table policies written before any production use.
- **seed.sql** — idempotently seeds the 9 workspace metadata rows, 6 curated example configurations and 8 tags (`on conflict do nothing`). No user data is seeded.

The current state, explicitly:

- The landing does **not** connect to Supabase.
- The landing does **not** install a Supabase client.
- The landing requires **no environment variables**.
- Everything renders from `src/data/*`.

The intended swap path is already prepared: the sections render from the `workspaceMetadata`, `featuredExamples` and `featureConcepts` collections, whose shapes mirror the future `workspace_metadata` and `examples` tables. A future Supabase client can replace the data source without redesigning the UI.

## What is currently local/mock

- All workspace metadata, engine capabilities, feature concepts and example configurations come from `src/data/*`.
- All CTAs link out to the real simulator and the GitHub repository.
- All interactive demos are self-contained re-implementations of the simulator's phenomena, not embeds of its engine.

## Accessibility & performance

- Semantic HTML landmarks, a skip-to-content link, keyboard-operable controls, visible focus states and aria labels on the interactive canvases.
- `prefers-reduced-motion` is respected: auto-animations and reveal transitions pause or bypass entirely, while user-driven interactions (dragging, sliders) remain fully functional.
- Canvases render only while in view; animation loops stop off-screen and on hidden tabs.
- `requestAnimationFrame` loops are cancelled on unmount and observers are disconnected.
- Hi-DPI canvases cap the device pixel ratio at 2 to keep fill-rate affordable.

## License

The landing presents Mathematics Simulator as an MIT-licensed project; the license itself lives in the main repository.
