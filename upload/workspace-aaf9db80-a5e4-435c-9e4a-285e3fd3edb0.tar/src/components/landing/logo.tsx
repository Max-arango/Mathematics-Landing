import { cn } from "@/lib/utils";
import { SITE } from "@/lib/site";

interface LogoProps {
  className?: string;
  /** show the wordmark next to the mark */
  wordmark?: boolean;
  dark?: boolean;
}

/** Plot-mark logo: a framed sine curve over faint axes. */
export function LogoMark({ className, dark }: { className?: string; dark?: boolean }) {
  return (
    <svg
      viewBox="0 0 32 32"
      aria-hidden="true"
      className={cn("size-7 shrink-0", className)}
      fill="none"
    >
      <rect
        x="1.25"
        y="1.25"
        width="29.5"
        height="29.5"
        rx="7"
        strokeWidth="1.5"
        stroke={dark ? "#f0eee5" : "#1b1a16"}
      />
      <line x1="8" y1="24" x2="26" y2="24" stroke={dark ? "#f0eee5" : "#1b1a16"} strokeWidth="1" opacity="0.3" />
      <line x1="8" y1="8" x2="8" y2="24" stroke={dark ? "#f0eee5" : "#1b1a16"} strokeWidth="1" opacity="0.3" />
      <path
        d="M8 19.5 C 10.5 19.5, 11 11, 14 11 S 16.5 24, 19.5 24 S 23 14, 26 14"
        stroke="#c2451d"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function Logo({ className, wordmark = true, dark }: LogoProps) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark dark={dark} />
      {wordmark && (
        <span
          className={cn(
            "text-[15px] font-semibold tracking-tight",
            dark ? "text-cream" : "text-ink"
          )}
        >
          {SITE.name}
        </span>
      )}
    </span>
  );
}
