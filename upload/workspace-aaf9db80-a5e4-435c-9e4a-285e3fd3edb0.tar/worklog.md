# Mathematics Simulator — Landing Page Build

Project: standalone landing page for **Mathematics Simulator** (open-source math exploration).
Repo: https://github.com/Max-arango/Mathematics-simulator · Live app: https://mathematics-simulator.vercel.app

Environment: Next.js 16 (App Router) at /home/z/my-project, port 3000, Tailwind 4 + shadcn/ui, dev server already running.
Constraints: single route `/` (src/app/page.tsx), no backend/API/Supabase connection at runtime, local demo data only, supabase/*.sql as future-ready artifacts.

Design direction: "Mathematical Laboratory" — light paper background, ink typography (Inter + Instrument Serif), vermilion accent (#C2451D), teal secondary (#2E7D6E), graph-paper textures, dark "phenomenon" panels for fractals / geometry viewport / final CTA. Real canvas-based math demos: hero 3D surface, f(x)=a·sin(bx+c) playground, fractal explorer (Mandelbrot/Julia/Burning Ship/Tricorn/Newton), sphere→torus→tesseract, Van der Pol phase portrait, Inspector AST/critical points, Notebook reproducible cells.

Task plan:
- 1: scaffold inspection + worklog (main agent)
- 2-a: supabase/schema.sql + supabase/seed.sql (subagent)
- 3..17: design system, data layer, shared primitives, navbar, hero, engine, workspaces, interactive, fractals, geometry, dynamics, inspector, notebook, why/open-source/CTA, page composition + SEO (main agent)
- 18-b: README.md (subagent)
- 19: lint + dev.log check (main agent)
- 20: agent-browser E2E verification + fixes (main agent)

---
Task ID: 1
Agent: main (Z.ai Code)
Task: Inspect project scaffold, verify dev server, create shared worklog

Work Log:
- Read package.json, src/app/layout.tsx, page.tsx, globals.css; confirmed Next.js 16.1.3 + Tailwind 4 + full shadcn/ui set (Button, Slider, Tabs, etc.), lucide-react, framer-motion.
- Confirmed dev server running on port 3000 (next dev, Turbopack), GET / 200.
- Created /home/z/my-project/worklog.md (this file).

Stage Summary:
- Scaffold understood; dev server healthy; worklog initialized. Proceeding to design system (Task 3) and delegating supabase SQL (Task 2-a).

---
Task ID: 2-a
Agent: general-purpose (supabase-sql)
Task: Create supabase/schema.sql and supabase/seed.sql for future integration

Work Log:
- Read worklog.md for context: landing runs fully on local data, no runtime Supabase; these SQL files are future-ready artifacts only.
- Checked validation tooling: psql / postgres / pg_isready are NOT installed in this sandbox (no server either), and no SQL parser libs (sqlglot/pglast/sqlparse) available → fell back to manual review + scripted checks as prescribed.
- Created /home/z/my-project/supabase/ and wrote schema.sql: header block (not applied, RLS intentionally off, TODO before production), `create extension if not exists "pgcrypto"`, pg_catalog sanity DO-block (verifies gen_random_uuid() resolvable), 3 enums in duplicate_object-swallowing DO blocks, a guarded auth.users shim (no-op on Supabase, stand-in on bare Postgres so the file runs top-to-bottom anywhere), 7 domain tables + tags + 3 join tables (all uuid pk / created_at / updated_at / FKs with explicit on delete, inline named constraints, comment on table + columns), 7 helper indexes incl. partial index on examples(featured) where featured, shared set_updated_at() trigger function applied via drop+create to all 6 tables with updated_at, and a fully commented-out "FUTURE: Row Level Security" block (10 prepared alter statements + TODO + verification query).
- Wrote seed.sql: 9 workspace_metadata rows (descriptors, routes, icons, sort_order 1..9), 6 examples (mandelbrot-deep-zoom, tesseract-double-rotation, van-der-pol-limit-cycle flagged featured=true), 8 tags; all inserts use on conflict do nothing; no profiles/projects/notebooks/user data seeded.
- Validated: python tokenizer (comment/string/$$-block aware) — 92 top-level statements in schema.sql all terminated by ";", no unterminated strings or $$ blocks, parentheses balanced, begin=end=5 across DO blocks/function bodies, all 9 jsonb literals parse as valid JSON with balanced parens; cross-checked statement counts (3 create type, 11 create table incl. shim, 7 create index, 6 create trigger, 44 comment on, 3 inserts) and confirmed 0 uncommented RLS statements; then manually re-read both files line-by-line for syntax review (psql unavailable).

Stage Summary:
- Deliverables: /home/z/my-project/supabase/schema.sql and /home/z/my-project/supabase/seed.sql. No other files touched; no builds/servers run.
- Enums: visibility_type (public/private/unlisted), workspace_type (calculator, fractal_lab, bloch_sphere, four_d, topology, dynamics, inspector, notebook, docs), experiment_status (draft/running/completed/failed; used by experiments.status, default 'draft').
- Tables: profiles (id -> auth.users on delete cascade), workspace_metadata (unique on workspace AND sort_order for deterministic nav order), projects (unique(user_id, slug), 3 indexes), experiments, notebooks (jsonb cell array), examples (unique slug, partial featured index), tags, experiment_tags / project_tags / notebook_tags (composite PKs, cascade both sides).
- Key decisions: auth.users shim keeps the file runnable on bare Postgres while being a no-op on Supabase; tags + join tables have no updated_at/trigger by design; seed uses bare on conflict do nothing on the two-constraint tables (workspace_metadata, tags) and on conflict (slug) for examples; featured=true on 3 of 6 examples.
- Validation result: PASS via manual line-by-line review + scripted balance checks (statement termination, parens, begin/end, JSON literal validity) since psql is not installed in this environment. Files remain unapplied design artifacts; RLS must be enabled + policies written before any production use.

---
Task ID: 18-b
Agent: general-purpose (readme)
Task: Write README.md for the landing

Work Log:
- Read worklog.md for full build context (design direction, constraints, prior stages).
- Verified facts before writing: package.json scripts (dev/build/start/lint); src/app/layout.tsx (self-hosted Inter / Instrument Serif / JetBrains Mono via next/font/local, full metadata incl. license MIT, Open Graph, canonical); src/app/page.tsx (single route, section order incl. WhySection); LS of src/components/landing (18 files) and src/components/math (9 files incl. hooks.ts, lib.ts).
- Read src/data/workspaces.ts (9 workspaces + engineCapabilities + stackChips), features.ts (4 featureConcepts), examples.ts (6 featuredExamples); confirmed the documented swap path (local data mirrors future workspace_metadata / examples tables).
- Read supabase/schema.sql header (RLS intentionally commented out, security TODO) + grep-confirmed 11 create-table statements (7 domain tables + tags + 3 join tables, plus auth.users shim); read seed.sql header (9 workspaces, 6 examples, 8 tags, idempotent on conflict do nothing).
- Verified demo claims in source: fractal-demo (mandelbrot/julia/burning_ship/tricorn/newton modes), geometry-demo (sphere/torus/tesseract, XY/ZW rotation sliders), dynamics-demo (Van der Pol, RK4), inspector-demo (AST/derivative/critical points), notebook-demo (reactive dependency-ordered cells), hero-visualization (pseudo-3D surface wireframe), function-demo (a·sin(bx+c) lab).
- Verified accessibility/perf claims: hooks.ts (usePrefersReducedMotion, useInView, sizeCanvas dprCap=2), cancelAnimationFrame cleanup present in all animated demos, reveal.tsx reduced-motion bypass, open-source-section.tsx MIT content.
- Wrote /home/z/my-project/README.md (109 lines): title/description, live links, page sections, tech stack, getting started, project structure, Supabase future integration (no runtime connection, no client, no env vars), local/mock list, accessibility & performance, license. No emojis, badges, or invented stats; only documented verified facts.

Stage Summary:
- Deliverable: /home/z/my-project/README.md, grounded in the actual codebase (every section fact-checked against source files). No other files modified; no build/dev commands run.

---
Task ID: 3–17, 19–21 (main agent)
Agent: main (Z.ai Code)
Task: Design system, data layer, all landing components & math demos, page composition, SEO, verification

Work Log:
- Design system: rewrote globals.css with a "Mathematical Laboratory" palette (paper #faf9f5 / ink #1b1a16 / vermilion #c2451d / teal #2e7d6e / void #131311), graph-paper textures, reveal + engine-pulse + notebook-run keyframes, dark-panel .lab-range slider styling, reduced-motion overrides.
- Fonts: Google Fonts download failed inside next/font → downloaded woff2 files via curl (Inter var, Instrument Serif + italic, JetBrains Mono var) into src/fonts and switched to next/font/local. Deterministic offline typography.
- Data layer: src/data/workspaces.ts (workspaceMetadata ×9 mirroring future supabase table, engineCapabilities ×27 from README, stackChips), features.ts (4 concepts), examples.ts (6 featuredExamples); src/lib/site.ts constants.
- Shared primitives: Reveal (IntersectionObserver, once), hooks (usePrefersReducedMotion, useInView, useElementSize, sizeCanvas w/ DPR cap), SectionHeading, InstrumentFrame (lab-instrument chrome), Logo.
- Components: Navbar (sticky, blurred, mobile hamburger w/ Escape close), Hero + HeroVisualization (rotating 3D surface z=2.2 sin(1.4r−0.85t)e^(−r²/26) as Canvas-2D wireframe, pointer tilt, hover vertex sampling, fps/θ/φ/t readouts, in-view + visibility pause, reduced-motion static), EngineSection (Expression→Lexer→Parser→AST→Engine→9 workspaces vertical pipeline + core index sheet), WorkspacesSection (9 cards, custom SVG/canvas mini-exhibits incl. mini-Mandelbrot + rotating tesseract), InteractiveSection + FunctionDemo (a·sin(bx+c) live sliders, derivative overlay, tangent probe, computed quantities), FractalSection + FractalDemo (Mandelbrot/Julia/Burning Ship/Tricorn/Newton; smooth coloring; progressive draft→final rendering with time-budgeted row chunks; wheel/click zoom; Julia drag-to-set-c; 3 palettes), GeometrySection + GeometryDemo (sphere/torus/tesseract; 4D→3D→2D double rotation with XY/ZW sliders; drag to orbit; dimension ladder D=0..4), DynamicsSection + DynamicsDemo (Van der Pol ẋ=y, ẏ=μ(1−x²)y−x; RK4 trajectories; vector field; draggable/clickable seeds; flowing particles), InspectorSection + InspectorDemo (3 expressions; hand-built AST trees with hover subtree highlight; numeric root-finding + f″ classification; critical-point table + marked plot), NotebookSection + NotebookDemo (draft vs committed params, stale→computed cascade, auto-run debounce, FWHM/integral readouts), WhySection, OpenSourceSection (evidence-based: MIT + stack only), FinalCta (dark, Lissajous backdrop), Footer (mt-auto sticky-bottom).
- SEO: metadata (title/description/OG/Twitter/canonical/robots), app/icon.svg, app/opengraph-image.tsx (ImageResponse, verified 200/71KB).
- Fixed all lint errors: setState-in-effect fallbacks → rAF; ref-during-render writes → sync effects; memoization inference (field inside useMemo); removed stale disable directives.
- Browser E2E (agent-browser + VLM review): hero surface animates at 60fps; slider interaction changes formula (2→2.25); derivative toggle works; Julia c drag (−0.7+0.27i → −0.1152+0.5355i); zoom Δ 3.0→1.5; geometry object switch + orbit drag; dynamics seed drop (seeds 4→5) + μ live update; inspector x⁴−4x² critical points exactly ±√2/0; notebook auto-run integral matches a·σ·√2π; mobile 375px: hero, hamburger menu open/navigate/close, no horizontal overflow, footer at bottom; zero console errors/page errors.
- Bug fixed from E2E: negative rAF delta during rapid re-renders corrupted dynamics particle index (TypeError pts[i]) → dt clamped ≥0, index bounded, phase wrapped; setPointerCapture wrapped in try/catch (3 demos).

Stage Summary:
- Landing fully built and browser-verified on desktop + mobile: 15 sections, 7 real interactive math demos, local-only data, supabase SQL artifacts + README in place. Lint clean, dev server healthy on :3000, no runtime errors.
